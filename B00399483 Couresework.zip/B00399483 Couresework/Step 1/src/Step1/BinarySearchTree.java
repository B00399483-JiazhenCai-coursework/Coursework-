package Step1;


public class BinarySearchTree {
	
	private Node root; // root

    public Node getRoot() {
        return root;
    }

    // Find element
    public Node find(Pet node) {
        if (root == null) {
            return null;
        }
        return find(root, node);
    }

    // Query element (recursive)
    private Node find(Node node, Pet element) {
        if (node == null) {
            return null;
        }
        int compareResult = node.element.compareTo(element);
        if (compareResult < 0) {
            return find(node.left, element);
        } else if (compareResult > 0) {
            return find(node.right, element);
        } else {
            return node;
        }
    }
    
    // Add element
    public boolean add(Pet element) {
        if (root == null) {
            root = new Node(element);
            return true;
        }
        return add(root, element);
    }
    // Add elements (recursive)
    private boolean add(Node node, Pet element) {
        if (node.element.compareTo(element) < 0) {
            if (node.left == null) {
                node.left = new Node(element);
                return true;
            } else {
                return add(node.left, element);
            }
        } else if (node.element.compareTo(element) > 0) {
            if (node.right == null) {
                node.right = new Node(element);
                return true;
            } else {
                return add(node.right, element);
            }
        } else {
            return false;
        }
    }

    // Traverse nodes
    public void orderPrint() {
        orderPrint(root);
    }
    
 // Traverse nodes (recursively)
    private void orderPrint(Node node) {
        if (node == null) {
            return;
        }
        // Recursive left child node
        if (node.left != null) {
            orderPrint(node.left);
        }

        // Output current node
        System.out.println(node.element.toString());

        // Recursive right child
        if (node.right != null) {
            orderPrint(node.right);
        }
    }
    
 // Delete node
    public boolean remove(Pet element) {
        if (root == null) {
            return false;
        }
        // If the deleted element is root
        if (root.element.compareTo(element) == 0) {
            if (root.right == null) {
                root = root.left;
            } else {
                root.right.left = root.left;
                root = root.right;
            }
            return true;
        }
        return remove(null, root, element);
    }

    // Delete node (recursively)
    private boolean remove(Node parentNode, Node node, Pet element) {
        if (node == null) {
            return false;
        }
        // Find the target element first
        int compareResult = node.element.compareTo(element);
        if (compareResult < 0) {
            return remove(node, node.left, element);
        }
        if (compareResult > 0) {
            return remove(node, node.right, element);
        }

        // Find the target element and determine whether the node is the left subtree or the right subtree of the parent node
        boolean isLeftOfParent = false;
        if (parentNode.left != null && parentNode.left.element.compareTo(element) == 0) {
            isLeftOfParent = true;
        }

        // Delete target element
        if (node.left == null && node.right == null) { // (1) The target element is a leaf node, directly delete it
            if (isLeftOfParent) {
                parentNode.left = null;
            } else {
                parentNode.right = null;
            }
        } else if (node.left != null && node.right != null) { // (2)The target element has both a left subtree and a right subtree
            //Find the minimum value of the right subtree (leaf node) and delete it
            Node minNode = findMin(node.right);
            remove(minNode.element);
            // Replace the minimum value with the target node to be deleted
            minNode.left = node.left;
            minNode.right = node.right;
            if(isLeftOfParent) {
                parentNode.left = minNode;
            } else {
                parentNode.right = minNode;
            }

        } else { // (3) The target element has only the left subtree or only the right subtree
            if (isLeftOfParent) {
                parentNode.left = node.left != null ? node.left : node.right;
            } else {
                parentNode.right = node.left != null ? node.left : node.right;
            }
        }
        return true;
    }
    
    /**
     * Find the maximum
     *
     * @return
     */
    private Node findMax() {
        return findMax(root);
    }

    /**
     * Find the maximum value (recursive)
     *
     * @param node
     * @return
     */
    private Node findMax(Node node) {
        if (node.right == null) {
            return node;
        }
        return findMax(node.right);
    }

    /**
     * Find the smallest value
     *
     * @return
     */
    private Node findMin() {
        return findMin(root);
    }

    /**
     * Find the smallest value (recursive)
     *
     * @param node
     * @return
     */
    private Node findMin(Node node) {
        if (node.left == null) {
            return node;
        }
        return findMin(node.left);
    }
    
    
    public static class Node {
        public Pet element;
        public Node left;
        public Node right;

        public Node(Pet element) {
            this.element = element;
        }

        @Override
        public String toString() {
            return element.toString();
        }
    }

}
