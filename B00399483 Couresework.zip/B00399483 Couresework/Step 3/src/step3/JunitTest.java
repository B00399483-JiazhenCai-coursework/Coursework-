package step3;

import org.junit.jupiter.api.Test;

public class JunitTest {

    @Test
    public void test() {
        PetProductTest.add("dog");
        PetProductTest.displayProduct("dog");
        PetProductTest.add("dog", "Bedding", "P111", 20);
        PetProductTest.add("dog", "Crate", "P222", 15);
        PetProductTest.add("dog", "Attire", "P333", 0);
        PetProductTest.add("cat", "Gates", "P222", 20);
        PetProductTest.add("cat");
        PetProductTest.add("cat", "Gates", "P222", 20);
        PetProductTest.find("pig");
        PetProductTest.find("dog");
        System.out.println("-------------------------");
        PetProductTest.displayProduct("dog");
        System.out.println("-------------------------");
        PetProductTest.displayPets();
        System.out.println("-------------------------");
        PetProductTest.displayProducts();
        System.out.println("-------------------------");
        PetProductTest.remove("dog", "P222");
        System.out.println("-------------------------");
        PetProductTest.displayProduct("dog");
        System.out.println("-------------------------");
        PetProductTest.find("dog");
        System.out.println("-------------------------");
        PetProductTest.remove("cat");
        System.out.println("-------------------------");
        PetProductTest.find("cat");
        System.out.println("-------------------------");
        PetProductTest.displayPets();

    }

}
