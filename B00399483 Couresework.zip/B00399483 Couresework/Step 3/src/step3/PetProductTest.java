package step3;

import bst.BinarySearchTree;
import list.NodeList;
import model.Pet;
import model.Product;

import java.util.Scanner;

public class PetProductTest {
    private final static BinarySearchTree bst = new BinarySearchTree();

    // Add details of a new pet type;
    public static void add(String name) {
        Pet pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            bst.add(pet);
            System.out.println("Added new pet successfully");
        } else {
            System.out.println("The pet already exists");
        }
    }

    // Add details of a new product for a specified pet type;
    public static void add(String petName, String productName, String productCode, int quantity) {
        Pet pet = new Pet(petName);
        Product product = new Product(productName, productCode, quantity);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            node.list.add(product);
            System.out.println("Added product successfully for pet " + petName);
        }
    }

    // Find if the company stocks products for a particular type of pet;
    public static void find(String name) {
        Pet pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            System.out.println(node);
        }

    }

    // Display all the products stocked for a specific pet type;
    public static void displayProduct(String name) {
        Pet Pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(Pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            // Showing fully stocked products
            NodeList products = node.list;
            NodeList.Node root = products.getRoot();
            while (root != null) {
                if (root.e.getQuantity() > 0) {
                    System.out.println(root.e);
                }
                root = root.next;
            }
        }
    }

    // Display all the product details for all the pets;
    public static void displayPets() {
        BinarySearchTree.Node root = bst.getRoot();
        displayPets(root);
    }

    private static void displayPets(BinarySearchTree.Node node) {
        if (node == null) {
            return;
        }
        // Recursive left child node
        if (node.left != null) {
            displayPets(node.left);
        }
        // Output the current node
        NodeList products = node.list;
        if (products.size() > 0) {
            System.out.println(node.element.toString());
        }

        // Recursive right child node
        if (node.right != null) {
            displayPets(node.right);
        }
    }

    // Display all the types of pets that the company provides products for;
    public static void displayProducts() {
        BinarySearchTree.Node root = bst.getRoot();
        displayProducts(root);
    }

    private static void displayProducts(BinarySearchTree.Node node) {
        if (node == null) {
            return;
        }
        // Recursive left child node
        if (node.left != null) {
            displayProducts(node.left);
        }
        // Output the current node
        NodeList products = node.list;
        System.out.println(products);

        // Recursive right child node
        if (node.right != null) {
            displayProducts(node.right);
        }
    }

    // Remove a particular product for a specified pet (eg discontinued ítem);
    public static void remove(String petName, String code) {
        Pet Pet = new Pet(petName);
        BinarySearchTree.Node node = bst.find(Pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            node.list.remove(new Product(null, code, 0));
            System.out.println("Product deleted successfully");
        }
    }

    // Remove a pet type from the system.
    public static void remove(String name) {
        Pet Pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(Pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            bst.remove(Pet);
            System.out.println("Pet deleted successfully");
        }

    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Operation Option:");
        System.out.println(" add pet_name");
        System.out.println(" add pet_name product_name product_code quantity");
        System.out.println(" find pet_name");
        System.out.println(" display_product pet_name");
        System.out.println(" display_pets");
        System.out.println(" display_products");
        System.out.println(" remove pet_name");
        System.out.println(" remove pet_name product_code");
        System.out.println(" exit");
        while (true){
            String key=scanner.nextLine();
            if (key.length() == 0) {
                continue;
            }
            System.out.println(key);
            String[] strs = key.split("\\s+");
            if (strs.length == 0) {
                System.out.println("invalid menu option entered");
                continue;
            }
            if ("add".equals(strs[0])) {
                if (strs.length == 5) {
                    try {
                        Integer.parseInt(strs[4]);
                    } catch (NumberFormatException e) {
                        System.out.println("the quantity should be a number");
                        continue;
                    }
                    add(strs[1], strs[2], strs[3], Integer.parseInt(strs[4]));
                } else if (strs.length == 2) {
                    add(strs[1]);
                } else {
                    System.out.println("invalid menu option entered");
                }
            } else if ("find".equals(strs[0])) {
                if (strs.length != 2) {
                    System.out.println("invalid menu option entered");
                } else {
                    find(strs[1]);
                }

            } else if ("display_product".equals(strs[0])) {
                if (strs.length == 2) {
                    displayProduct(strs[1]);
                } else {
                    System.out.println("invalid menu option entered");
                }

            } else if ("display_pets".equals(strs[0])) {
                if (strs.length == 1) {
                    displayPets();
                } else {
                    System.out.println("invalid menu option entered");
                }

            }  else if ("display_products".equals(strs[0])) {
                if (strs.length == 1) {
                    displayProducts();
                } else {
                    System.out.println("invalid menu option entered");
                }

            } else if ("remove".equals(strs[0])) {
                if (strs.length == 2) {
                    remove(strs[1]);
                } else if (strs.length == 3) {
                    remove(strs[1], strs[2]);
                } else {
                    System.out.println("invalid menu option entered");
                }
            } else if ("exit".equals(strs[0])) {
                break;
            } else {
                System.out.println("invalid menu option entered");
            }
        }


    }

}
