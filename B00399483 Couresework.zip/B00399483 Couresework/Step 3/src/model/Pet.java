package model;

public class Pet implements Comparable<Pet> {
    // pet name
    private String name;
    
    //Constructor of Pet
    public Pet(String name) {
        this.name = name;
    }

    //Get pet name
    public String getName() {
        return name;
    }

    //Set pet name
    public void setName(String name) {
        this.name = name;
    }

    //Override toString method from Object class
    @Override
    public String toString() {
        return "Pet" +" "+
                "name=" + " "+ name  ;
    }
    
    //Compare two different pet objects for insertion and search in a binary tree
    @Override
    public int compareTo(Pet o) {
        return o.getName().compareTo(this.name);
    }
}
