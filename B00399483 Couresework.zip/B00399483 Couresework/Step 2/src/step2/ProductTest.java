package step2;

import java.util.Scanner;



public class ProductTest {
	 private static final NodeList list = new NodeList();

	    // interacts with the user to add the pet product details;
	    public static void addProduct(String name, String code, int quantity) {
	        Product product = new Product(name, code, quantity);
	        Product result = null;
	        if (list.size() > 0) {
	            result = list.search(product);
	        }
	        if (result != null) {
	            System.out.println("Product already in the system");
	        } else {
	            list.add(product);
	            System.out.println("Product added successfully");
	        }
	    }

	    // which searches for a particular product and displays the details if found;
	    public static void findProduct (String code) {
	        Product product = new Product(null, code, 0);
	        Product result = null;
	        if (list.size() > 0) {
	            result = list.search(product);
	        }
	        if (result == null) {
	            System.out.println("Product not found");
	        } else {
	            System.out.println(result);
	        }
	    }

	    // remove a specific product from the system if they are no longer stocked
	    public static void removeProduct (String code) {
	        Product product = new Product(null, code, 0);
	        Product result = null;
	        if (list.size() > 0) {
	            result = list.search(product);
	        }
	        if (result == null) {
	            System.out.println("No product in the system");
	        } else {
	            list.remove(product);
	            System.out.println("Product deleted successfully");
	        }
	    }

	    // displays all the products;
	    public static void displayProducts () {
	        if (list.size() == 0) {
	            System.out.println("no products in the system to display");
	            return;
	        }
	        System.out.println(list);
	    }
	    
	    public static void main(String[] args) {
	        Scanner scanner=new Scanner(System.in);
	        System.out.println("Option:");
	        System.out.println(" add name code quantity");
	        System.out.println(" find code");
	        System.out.println(" remove code");
	        System.out.println(" display");
	        System.out.println(" exit");
	        while (true){
	            String key=scanner.nextLine();
	            if (key.length() == 0) {
	                continue;
	            }
	            System.out.println(key);
	            String[] strs = key.split("\\s+");
	            if (strs.length == 0) {
	                System.out.println("invalid menu option entered");
	                continue;
	            }
	            if ("add".equals(strs[0])) {
	                if (strs.length == 4) {
	                    try {
	                        Integer.parseInt(strs[3]);
	                    } catch (NumberFormatException e) {
	                        System.out.println("the quantity should be a number");
	                        continue;
	                    }
	                    addProduct(strs[1], strs[2], Integer.parseInt(strs[3]));
	                } else {
	                    System.out.println("invalid menu option entered");
	                }
	            } else if ("find".equals(strs[0])) {
	                if (strs.length == 2) {
	                    findProduct(strs[1]);
	                } else {
	                    System.out.println("invalid menu option entered");
	                }

	            } else if ("display".equals(strs[0])) {
	                if (strs.length == 1) {
	                    displayProducts();
	                } else {
	                    System.out.println("invalid menu option entered");
	                }

	            } else if ("remove".equals(strs[0])) {
	                if (strs.length == 2) {
	                    removeProduct(strs[1]);
	                } else {
	                    System.out.println("invalid menu option entered");
	                }
	            } else if ("exit".equals(strs[0])) {
	                break;
	            } else {
	                System.out.println("invalid menu option entered");
	            }
	        }
	    }
}
