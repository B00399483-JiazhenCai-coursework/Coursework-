package step1;

import bst.BinarySearchTree;
import model.Pet;
import org.junit.jupiter.api.Test;

import java.util.Scanner;

public class PetTest {
    private final static BinarySearchTree bst = new BinarySearchTree();

    // add a new pet type;
    public static void add(String name) {
        Pet pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            bst.add(pet);
            System.out.println("Added new pet successfully");
        } else {
            System.out.println("The pet already exists");
        }
    }

    // find if the company provides products for a particular pet type;
    public static void find(String name) {
        Pet pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            System.out.println("Find the pet named " + name);
        }
    }

    // display a specific pet type;
    public static void display(String name) {
        Pet pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            System.out.println("No pet found");
        } else {
            System.out.println(node);
        }
    }

    // display the details of all the pet types
    // the company provides products for inalphabetical order
    public static void display() {
        bst.orderPrint();
    }

    // o remove a specific pet type;
    public static void remove(String name) {
        Pet pet = new Pet(name);
        BinarySearchTree.Node node = bst.find(pet);
        if (node == null) {
            System.out.println("No pets in the system");
            return;
        }
        boolean remove = bst.remove(pet);
        System.out.println("Pet deleted successfully");
    }

    @Test
    public void test() {
        add("dog");
        add("cat");
        add("panda");
        add("snake");
        add("fox");
        add("tiger");
        add("bird");
        display();
        System.out.println("-----------------");
        display("pig");
        System.out.println("-----------------");
        display("dog");
        System.out.println("-----------------");
        remove("dog");
        display();
        System.out.println("-----------------");
        find("dog");
        System.out.println("-----------------");
        find("snake");
        System.out.println("-----------------");
        remove("bird");
        System.out.println("-----------------");
        display();
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Opetration Option:");
        System.out.println(" add name");
        System.out.println(" find name");
        System.out.println(" display [name]");
        System.out.println(" remove name");
        System.out.println(" exit");
        while (true){
            String key=scanner.nextLine();
            if (key.length() == 0) {
                continue;
            }
            System.out.println(key);
            String[] strs = key.split("\\s+");
            if (strs.length == 0) {
                System.out.println("invalid menu option entered");
                continue;
            }
            if ("add".equals(strs[0])) {
                if (strs.length != 2) {
                    System.out.println("invalid menu option entered");
                } else {
                    add(strs[1]);
                }
            } else if ("find".equals(strs[0])) {
                if (strs.length != 2) {
                    System.out.println("invalid menu option entered");
                } else {
                    find(strs[1]);
                }

             } else if ("display".equals(strs[0])) {
                if (strs.length == 1) {
                    display();
                } else if (strs.length == 2){
                    display(strs[1]);
                } else {
                    System.out.println("invalid menu option entered");
                }

            } else if ("remove".equals(strs[0])) {
                if (strs.length != 2) {
                    System.out.println("invalid menu option entered");
                } else {
                    remove(strs[1]);
                }
            } else if ("exit".equals(strs[0])) {
                break;
            } else {
                System.out.println("invalid menu option entered");
            }
        }
    }

}
