package step2;


public class NodeList {
	 //Inner class
    public class Node {
        public Product e;
        public Node next;
        public Node() {
            this(null, null);
        }

        public Node(Product e) {
            this(e, null);
        }
        public Node(Product e, Node next) {
            this.e = e;
            this.next = next;
        }

        public void addNode(Node node) {
            //Determine whether the current node is empty, add it if it is empty
            if (this.next == null) {
                this.next = node;
            } else {
                next.addNode(node);
            }
        }


        public Product searchNode(Product e) {
            if (this.e.equals(e)) {
                return this.e;
            } else if (this.next != null) {
                return this.next.searchNode(e);
            }
            return null;
        }

        public void remove(Node node, Product e) {
            if (this.e.equals(e)) {
                node.next = this.next;
                size--;
            } else {
                this.next.remove(this, e);
            }
        }

        @Override
        public String toString() {
            StringBuilder s = new StringBuilder();
            Node cur = this;
            while (cur != null) {
                s.append(cur.e + " -> ");
                cur = cur.next;
            }
            s.append("NULL");
            return s.toString();
        }
    }
    
    private Node root;

    private int size;

    public Node getRoot() {
        return root;
    }

    public void add(Product e) {
        Node node = new Node(e);
        if (this.root == null) {
            root = node;
        } else {
            root.addNode(node);
        }
        size++;
    }

    public void remove(Product e) {
        if (search(e) != null) {
            this.root.remove(root, e);
        }
    }

    public Product search(Product e) {
        return this.root.searchNode(e);
    }

    public int size() {
        return size;
    }

    @Override
    public String toString() {
        return root.toString();
    }
}
